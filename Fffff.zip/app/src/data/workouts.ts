export interface Exercise {
  name: string;
  nameRu: string;
  nameTr: string;
  nameEn: string;
  sets: number;
  reps: string;
  rest: string;
}

export interface WorkoutDay {
  day: number;
  focus: string;
  focusRu: string;
  focusTr: string;
  focusEn: string;
  exercises: Exercise[];
}

export interface WorkoutProgram {
  id: string;
  daysPerWeek: number;
  name: string;
  nameRu: string;
  nameTr: string;
  nameEn: string;
  description: string;
  descriptionRu: string;
  descriptionTr: string;
  descriptionEn: string;
  days: WorkoutDay[];
}

export const workoutPrograms: WorkoutProgram[] = [
  // 3 DAY PROGRAM - Full Body
  {
    id: '3day-fullbody',
    daysPerWeek: 3,
    name: 'Tam Bədən Proqramı',
    nameRu: 'Программа Full Body',
    nameTr: 'Tam Vücut Programı',
    nameEn: 'Full Body Program',
    description: 'Həftədə 3 gün tam bədən məşqi. Ən yaxşı nəticələr üçün hər məşq arasında 1 gün istirahət edin.',
    descriptionRu: 'Тренировка всего тела 3 раза в неделю. Отдыхайте 1 день между тренировками для лучших результатов.',
    descriptionTr: 'Haftada 3 gün tam vücut antrenmanı. En iyi sonuçlar için antrenmanlar arasında 1 gün dinlenin.',
    descriptionEn: 'Full body workout 3 times per week. Rest 1 day between workouts for best results.',
    days: [
      {
        day: 1,
        focus: 'Tam Bədən A',
        focusRu: 'Все Тело A',
        focusTr: 'Tam Vücut A',
        focusEn: 'Full Body A',
        exercises: [
          { name: 'Barbell Squat', nameRu: 'Приседания со штангой', nameTr: 'Barbell Squat', nameEn: 'Barbell Squat', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Bench Press', nameRu: 'Жим лёжа', nameTr: 'Bench Press', nameEn: 'Bench Press', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Bent Over Row', nameRu: 'Тяга в наклоне', nameTr: 'Bent Over Row', nameEn: 'Bent Over Row', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Overhead Press', nameRu: 'Жим над головой', nameTr: 'Overhead Press', nameEn: 'Overhead Press', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Lat Pulldown', nameRu: 'Тяга верхнего блока', nameTr: 'Lat Pulldown', nameEn: 'Lat Pulldown', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Leg Curl', nameRu: 'Сгибание ног', nameTr: 'Leg Curl', nameEn: 'Leg Curl', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Plank', nameRu: 'Планка', nameTr: 'Plank', nameEn: 'Plank', sets: 3, reps: '45-60 san', rest: '60 san' },
        ]
      },
      {
        day: 2,
        focus: 'Tam Bədən B',
        focusRu: 'Все Тело B',
        focusTr: 'Tam Vücut B',
        focusEn: 'Full Body B',
        exercises: [
          { name: 'Deadlift', nameRu: 'Становая тяга', nameTr: 'Deadlift', nameEn: 'Deadlift', sets: 4, reps: '6-8', rest: '3 dəq' },
          { name: 'Incline Dumbbell Press', nameRu: 'Жим гантелей на наклонной', nameTr: 'Incline Dumbbell Press', nameEn: 'Incline Dumbbell Press', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Pull-ups', nameRu: 'Подтягивания', nameTr: 'Pull-ups', nameEn: 'Pull-ups', sets: 3, reps: '8-12', rest: '90 san' },
          { name: 'Lunges', nameRu: 'Выпады', nameTr: 'Lunges', nameEn: 'Lunges', sets: 3, reps: '10 hər ayaq', rest: '90 san' },
          { name: 'Dumbbell Shoulder Press', nameRu: 'Жим гантелей сидя', nameTr: 'Dumbbell Shoulder Press', nameEn: 'Dumbbell Shoulder Press', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Bicep Curls', nameRu: 'Сгибание рук на бицепс', nameTr: 'Bicep Curls', nameEn: 'Bicep Curls', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Tricep Pushdowns', nameRu: 'Разгибание рук на трицепс', nameTr: 'Tricep Pushdowns', nameEn: 'Tricep Pushdowns', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 3,
        focus: 'Tam Bədən C',
        focusRu: 'Все Тело C',
        focusTr: 'Tam Vücut C',
        focusEn: 'Full Body C',
        exercises: [
          { name: 'Leg Press', nameRu: 'Жим ногами', nameTr: 'Leg Press', nameEn: 'Leg Press', sets: 4, reps: '10-12', rest: '2 dəq' },
          { name: 'Dumbbell Flyes', nameRu: 'Разведение гантелей', nameTr: 'Dumbbell Flyes', nameEn: 'Dumbbell Flyes', sets: 3, reps: '12-15', rest: '90 san' },
          { name: 'Seated Cable Row', nameRu: 'Тяга сидя к поясу', nameTr: 'Seated Cable Row', nameEn: 'Seated Cable Row', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameTr: 'Romanian Deadlift', nameEn: 'Romanian Deadlift', sets: 4, reps: '10-12', rest: '2 dəq' },
          { name: 'Lateral Raises', nameRu: 'Махи в стороны', nameTr: 'Lateral Raises', nameEn: 'Lateral Raises', sets: 3, reps: '15-20', rest: '60 san' },
          { name: 'Leg Extensions', nameRu: 'Разгибание ног', nameTr: 'Leg Extensions', nameEn: 'Leg Extensions', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Hanging Leg Raises', nameRu: 'Подъём ног в висе', nameTr: 'Hanging Leg Raises', nameEn: 'Hanging Leg Raises', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      }
    ]
  },
  // 4 DAY PROGRAM - Upper/Lower Split
  {
    id: '4day-upperlower',
    daysPerWeek: 4,
    name: 'Yuxarı/Aşağı Bölünmə',
    nameRu: 'Верх/Низ Сплит',
    nameTr: 'Üst/Alt Bölünme',
    nameEn: 'Upper/Lower Split',
    description: 'Həftədə 4 gün - Yuxarı və Aşağı bədən növbəli məşq. Güc və əzələ yığımı üçün idealdır.',
    descriptionRu: '4 дня в неделю - чередование верха и низа. Идеально для силы и набора мышц.',
    descriptionTr: 'Haftada 4 gün - Üst ve Alt vücut rotasyonu. Güç ve kas kazanımı için ideal.',
    descriptionEn: '4 days per week - Upper and Lower body rotation. Ideal for strength and muscle building.',
    days: [
      {
        day: 1,
        focus: 'Yuxarı Bədən A',
        focusRu: 'Верх Тела A',
        focusTr: 'Üst Vücut A',
        focusEn: 'Upper Body A',
        exercises: [
          { name: 'Bench Press', nameRu: 'Жим лёжа', nameTr: 'Bench Press', nameEn: 'Bench Press', sets: 4, reps: '6-8', rest: '2-3 dəq' },
          { name: 'Bent Over Row', nameRu: 'Тяга в наклоне', nameTr: 'Bent Over Row', nameEn: 'Bent Over Row', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Overhead Press', nameRu: 'Жим над головой', nameTr: 'Overhead Press', nameEn: 'Overhead Press', sets: 3, reps: '8-10', rest: '2 dəq' },
          { name: 'Lat Pulldown', nameRu: 'Тяга верхнего блока', nameTr: 'Lat Pulldown', nameEn: 'Lat Pulldown', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Incline Dumbbell Press', nameRu: 'Жим на наклонной', nameTr: 'Incline Dumbbell Press', nameEn: 'Incline Dumbbell Press', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Face Pulls', nameRu: 'Тяга к лицу', nameTr: 'Face Pulls', nameEn: 'Face Pulls', sets: 3, reps: '15-20', rest: '60 san' },
          { name: 'Barbell Curls', nameRu: 'Сгибание на бицепс', nameTr: 'Barbell Curls', nameEn: 'Barbell Curls', sets: 3, reps: '10-12', rest: '60 san' },
          { name: 'Skull Crushers', nameRu: 'Разгибание на трицепс', nameTr: 'Skull Crushers', nameEn: 'Skull Crushers', sets: 3, reps: '10-12', rest: '60 san' },
        ]
      },
      {
        day: 2,
        focus: 'Aşağı Bədən A',
        focusRu: 'Низ Тела A',
        focusTr: 'Alt Vücut A',
        focusEn: 'Lower Body A',
        exercises: [
          { name: 'Squat', nameRu: 'Приседания', nameTr: 'Squat', nameEn: 'Squat', sets: 4, reps: '6-8', rest: '3 dəq' },
          { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameTr: 'Romanian Deadlift', nameEn: 'Romanian Deadlift', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Leg Press', nameRu: 'Жим ногами', nameTr: 'Leg Press', nameEn: 'Leg Press', sets: 3, reps: '10-12', rest: '2 dəq' },
          { name: 'Walking Lunges', nameRu: 'Выпады вперёд', nameTr: 'Walking Lunges', nameEn: 'Walking Lunges', sets: 3, reps: '12 hər ayaq', rest: '90 san' },
          { name: 'Leg Curl', nameRu: 'Сгибание ног', nameTr: 'Leg Curl', nameEn: 'Leg Curl', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Calf Raises', nameRu: 'Подъёмы на носки', nameTr: 'Calf Raises', nameEn: 'Calf Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Hanging Leg Raises', nameRu: 'Подъём ног в висе', nameTr: 'Hanging Leg Raises', nameEn: 'Hanging Leg Raises', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 3,
        focus: 'Yuxarı Bədən B',
        focusRu: 'Верх Тела B',
        focusTr: 'Üst Vücut B',
        focusEn: 'Upper Body B',
        exercises: [
          { name: 'Pull-ups', nameRu: 'Подтягивания', nameTr: 'Pull-ups', nameEn: 'Pull-ups', sets: 4, reps: '8-12', rest: '2 dəq' },
          { name: 'Incline Bench Press', nameRu: 'Жим на наклонной скамье', nameTr: 'Incline Bench Press', nameEn: 'Incline Bench Press', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Seated Cable Row', nameRu: 'Тяга сидя к поясу', nameTr: 'Seated Cable Row', nameEn: 'Seated Cable Row', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Dumbbell Shoulder Press', nameRu: 'Жим гантелей сидя', nameTr: 'Dumbbell Shoulder Press', nameEn: 'Dumbbell Shoulder Press', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Chest Flyes', nameRu: 'Сведение в кроссовере', nameTr: 'Chest Flyes', nameEn: 'Chest Flyes', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Lateral Raises', nameRu: 'Махи в стороны', nameTr: 'Lateral Raises', nameEn: 'Lateral Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Hammer Curls', nameRu: 'Молотки', nameTr: 'Hammer Curls', nameEn: 'Hammer Curls', sets: 3, reps: '10-12', rest: '60 san' },
          { name: 'Cable Pushdowns', nameRu: 'Разгибание в блоке', nameTr: 'Cable Pushdowns', nameEn: 'Cable Pushdowns', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 4,
        focus: 'Aşağı Bədən B',
        focusRu: 'Низ Тела B',
        focusTr: 'Alt Vücut B',
        focusEn: 'Lower Body B',
        exercises: [
          { name: 'Deadlift', nameRu: 'Становая тяга', nameTr: 'Deadlift', nameEn: 'Deadlift', sets: 4, reps: '5-6', rest: '3 dəq' },
          { name: 'Front Squat', nameRu: 'Фронтальные приседания', nameTr: 'Front Squat', nameEn: 'Front Squat', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Bulgarian Split Squats', nameRu: 'Болгарские приседания', nameTr: 'Bulgarian Split Squats', nameEn: 'Bulgarian Split Squats', sets: 3, reps: '10 hər ayaq', rest: '90 san' },
          { name: 'Leg Extensions', nameRu: 'Разгибание ног', nameTr: 'Leg Extensions', nameEn: 'Leg Extensions', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Lying Leg Curl', nameRu: 'Сгибание ног лёжа', nameTr: 'Lying Leg Curl', nameEn: 'Lying Leg Curl', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Seated Calf Raises', nameRu: 'Подъёмы на носки сидя', nameTr: 'Seated Calf Raises', nameEn: 'Seated Calf Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Cable Crunches', nameRu: 'Скручивания в блоке', nameTr: 'Cable Crunches', nameEn: 'Cable Crunches', sets: 3, reps: '15-20', rest: '60 san' },
        ]
      }
    ]
  },
  // 5 DAY PROGRAM - Push/Pull/Legs + Upper/Lower
  {
    id: '5day-ppl',
    daysPerWeek: 5,
    name: 'Push/Pull/Legs + Yuxarı/Aşağı',
    nameRu: 'Push/Pull/Legs + Верх/Низ',
    nameTr: 'Push/Pull/Legs + Üst/Alt',
    nameEn: 'Push/Pull/Legs + Upper/Lower',
    description: 'Həftədə 5 gün - Push/Pull/Legs və Yuxarı/Aşağı kombinasiyası. Maksimum əzələ yığımı üçün.',
    descriptionRu: '5 дней в неделю - комбинация Push/Pull/Legs и Верх/Низ. Для максимального набора мышц.',
    descriptionTr: 'Haftada 5 gün - Push/Pull/Legs ve Üst/Alt kombinasyonu. Maksimum kas kazanımı için.',
    descriptionEn: '5 days per week - Push/Pull/Legs and Upper/Lower combination. For maximum muscle building.',
    days: [
      {
        day: 1,
        focus: 'Push A - Sinə, Çiyin, Trisep',
        focusRu: 'Push A - Грудь, Плечи, Трицепс',
        focusTr: 'Push A - Göğüs, Omuz, Triseps',
        focusEn: 'Push A - Chest, Shoulders, Triceps',
        exercises: [
          { name: 'Bench Press', nameRu: 'Жим лёжа', nameTr: 'Bench Press', nameEn: 'Bench Press', sets: 4, reps: '6-8', rest: '2-3 dəq' },
          { name: 'Incline Dumbbell Press', nameRu: 'Жим на наклонной', nameTr: 'Incline Dumbbell Press', nameEn: 'Incline Dumbbell Press', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Overhead Press', nameRu: 'Жим над головой', nameTr: 'Overhead Press', nameEn: 'Overhead Press', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Lateral Raises', nameRu: 'Махи в стороны', nameTr: 'Lateral Raises', nameEn: 'Lateral Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Cable Flyes', nameRu: 'Сведение в кроссовере', nameTr: 'Cable Flyes', nameEn: 'Cable Flyes', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Tricep Dips', nameRu: 'Отжимания на брусьях', nameTr: 'Tricep Dips', nameEn: 'Tricep Dips', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Overhead Tricep Extension', nameRu: 'Разгибание за головой', nameTr: 'Overhead Tricep Extension', nameEn: 'Overhead Tricep Extension', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 2,
        focus: 'Pull A - Arxa, Bisep, Qollar',
        focusRu: 'Pull A - Спина, Бицепс, Руки',
        focusTr: 'Pull A - Sırt, Biseps, Kollar',
        focusEn: 'Pull A - Back, Biceps, Arms',
        exercises: [
          { name: 'Deadlift', nameRu: 'Становая тяга', nameTr: 'Deadlift', nameEn: 'Deadlift', sets: 4, reps: '5-6', rest: '3 dəq' },
          { name: 'Pull-ups', nameRu: 'Подтягивания', nameTr: 'Pull-ups', nameEn: 'Pull-ups', sets: 4, reps: '8-12', rest: '2 dəq' },
          { name: 'Barbell Row', nameRu: 'Тяга штанги в наклоне', nameTr: 'Barbell Row', nameEn: 'Barbell Row', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Seated Cable Row', nameRu: 'Тяга сидя к поясу', nameTr: 'Seated Cable Row', nameEn: 'Seated Cable Row', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Face Pulls', nameRu: 'Тяга к лицу', nameTr: 'Face Pulls', nameEn: 'Face Pulls', sets: 3, reps: '15-20', rest: '60 san' },
          { name: 'Barbell Curls', nameRu: 'Сгибание штанги', nameTr: 'Barbell Curls', nameEn: 'Barbell Curls', sets: 4, reps: '10-12', rest: '60 san' },
          { name: 'Hammer Curls', nameRu: 'Молотки', nameTr: 'Hammer Curls', nameEn: 'Hammer Curls', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 3,
        focus: 'Legs A - Ayaqlar',
        focusRu: 'Legs A - Ноги',
        focusTr: 'Legs A - Bacaklar',
        focusEn: 'Legs A - Legs',
        exercises: [
          { name: 'Squat', nameRu: 'Приседания', nameTr: 'Squat', nameEn: 'Squat', sets: 4, reps: '6-8', rest: '3 dəq' },
          { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameTr: 'Romanian Deadlift', nameEn: 'Romanian Deadlift', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Leg Press', nameRu: 'Жим ногами', nameTr: 'Leg Press', nameEn: 'Leg Press', sets: 4, reps: '10-12', rest: '2 dəq' },
          { name: 'Walking Lunges', nameRu: 'Выпады вперёд', nameTr: 'Walking Lunges', nameEn: 'Walking Lunges', sets: 3, reps: '12 hər ayaq', rest: '90 san' },
          { name: 'Leg Extensions', nameRu: 'Разгибание ног', nameTr: 'Leg Extensions', nameEn: 'Leg Extensions', sets: 3, reps: '15-20', rest: '60 san' },
          { name: 'Leg Curl', nameRu: 'Сгибание ног', nameTr: 'Leg Curl', nameEn: 'Leg Curl', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Standing Calf Raises', nameRu: 'Подъёмы на носки стоя', nameTr: 'Standing Calf Raises', nameEn: 'Standing Calf Raises', sets: 5, reps: '15-20', rest: '60 san' },
        ]
      },
      {
        day: 4,
        focus: 'Yuxarı Bədən',
        focusRu: 'Верх Тела',
        focusTr: 'Üst Vücut',
        focusEn: 'Upper Body',
        exercises: [
          { name: 'Incline Bench Press', nameRu: 'Жим на наклонной', nameTr: 'Incline Bench Press', nameEn: 'Incline Bench Press', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Lat Pulldown', nameRu: 'Тяга верхнего блока', nameTr: 'Lat Pulldown', nameEn: 'Lat Pulldown', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Dumbbell Shoulder Press', nameRu: 'Жим гантелей сидя', nameTr: 'Dumbbell Shoulder Press', nameEn: 'Dumbbell Shoulder Press', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Chest Flyes', nameRu: 'Разведение гантелей', nameTr: 'Chest Flyes', nameEn: 'Chest Flyes', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'One-Arm Dumbbell Row', nameRu: 'Тяга одной рукой', nameTr: 'One-Arm Dumbbell Row', nameEn: 'One-Arm Dumbbell Row', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Incline Curls', nameRu: 'Сгибание на наклонной', nameTr: 'Incline Curls', nameEn: 'Incline Curls', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Rope Pushdowns', nameRu: 'Разгибание на канате', nameTr: 'Rope Pushdowns', nameEn: 'Rope Pushdowns', sets: 3, reps: '15-20', rest: '60 san' },
        ]
      },
      {
        day: 5,
        focus: 'Aşağı Bədən',
        focusRu: 'Низ Тела',
        focusTr: 'Alt Vücut',
        focusEn: 'Lower Body',
        exercises: [
          { name: 'Front Squat', nameRu: 'Фронтальные приседания', nameTr: 'Front Squat', nameEn: 'Front Squat', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Sumo Deadlift', nameRu: 'Сумо становая тяга', nameTr: 'Sumo Deadlift', nameEn: 'Sumo Deadlift', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Hack Squat', nameRu: 'Гакк-приседания', nameTr: 'Hack Squat', nameEn: 'Hack Squat', sets: 3, reps: '10-12', rest: '2 dəq' },
          { name: 'Bulgarian Split Squats', nameRu: 'Болгарские приседания', nameTr: 'Bulgarian Split Squats', nameEn: 'Bulgarian Split Squats', sets: 3, reps: '10 hər ayaq', rest: '90 san' },
          { name: 'Seated Leg Curl', nameRu: 'Сгибание ног сидя', nameTr: 'Seated Leg Curl', nameEn: 'Seated Leg Curl', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Seated Calf Raises', nameRu: 'Подъёмы на носки сидя', nameTr: 'Seated Calf Raises', nameEn: 'Seated Calf Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Plank', nameRu: 'Планка', nameTr: 'Plank', nameEn: 'Plank', sets: 3, reps: '60 san', rest: '60 san' },
        ]
      }
    ]
  },
  // 6 DAY PROGRAM - Push/Pull/Legs
  {
    id: '6day-ppl',
    daysPerWeek: 6,
    name: 'Push/Pull/Legs (2x)',
    nameRu: 'Push/Pull/Legs (2x)',
    nameTr: 'Push/Pull/Legs (2x)',
    nameEn: 'Push/Pull/Legs (2x)',
    description: 'Həftədə 6 gün - Push/Pull/Legs iki dəfə. Ən yüksək intensivlik, maksimum nəticələr üçün.',
    descriptionRu: '6 дней в неделю - Push/Pull/Legs дважды. Максимальная интенсивность для максимальных результатов.',
    descriptionTr: 'Haftada 6 gün - Push/Pull/Legs iki kez. Maksimum yoğunluk, maksimum sonuçlar için.',
    descriptionEn: '6 days per week - Push/Pull/Legs twice. Maximum intensity for maximum results.',
    days: [
      {
        day: 1,
        focus: 'Push A - Sinə, Çiyin, Trisep',
        focusRu: 'Push A - Грудь, Плечи, Трицепс',
        focusTr: 'Push A - Göğüs, Omuz, Triseps',
        focusEn: 'Push A - Chest, Shoulders, Triceps',
        exercises: [
          { name: 'Bench Press', nameRu: 'Жим лёжа', nameTr: 'Bench Press', nameEn: 'Bench Press', sets: 4, reps: '6-8', rest: '2-3 dəq' },
          { name: 'Incline Dumbbell Press', nameRu: 'Жим на наклонной', nameTr: 'Incline Dumbbell Press', nameEn: 'Incline Dumbbell Press', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Overhead Press', nameRu: 'Жим над головой', nameTr: 'Overhead Press', nameEn: 'Overhead Press', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Lateral Raises', nameRu: 'Махи в стороны', nameTr: 'Lateral Raises', nameEn: 'Lateral Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Cable Flyes', nameRu: 'Сведение в кроссовере', nameTr: 'Cable Flyes', nameEn: 'Cable Flyes', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Tricep Dips', nameRu: 'Отжимания на брусьях', nameTr: 'Tricep Dips', nameEn: 'Tricep Dips', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Overhead Tricep Extension', nameRu: 'Разгибание за головой', nameTr: 'Overhead Tricep Extension', nameEn: 'Overhead Tricep Extension', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 2,
        focus: 'Pull A - Arxa, Bisep',
        focusRu: 'Pull A - Спина, Бицепс',
        focusTr: 'Pull A - Sırt, Biseps',
        focusEn: 'Pull A - Back, Biceps',
        exercises: [
          { name: 'Deadlift', nameRu: 'Становая тяга', nameTr: 'Deadlift', nameEn: 'Deadlift', sets: 4, reps: '5-6', rest: '3 dəq' },
          { name: 'Pull-ups', nameRu: 'Подтягивания', nameTr: 'Pull-ups', nameEn: 'Pull-ups', sets: 4, reps: '8-12', rest: '2 dəq' },
          { name: 'Barbell Row', nameRu: 'Тяга штанги в наклоне', nameTr: 'Barbell Row', nameEn: 'Barbell Row', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Seated Cable Row', nameRu: 'Тяга сидя к поясу', nameTr: 'Seated Cable Row', nameEn: 'Seated Cable Row', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Face Pulls', nameRu: 'Тяга к лицу', nameTr: 'Face Pulls', nameEn: 'Face Pulls', sets: 3, reps: '15-20', rest: '60 san' },
          { name: 'Barbell Curls', nameRu: 'Сгибание штанги', nameTr: 'Barbell Curls', nameEn: 'Barbell Curls', sets: 4, reps: '10-12', rest: '60 san' },
          { name: 'Hammer Curls', nameRu: 'Молотки', nameTr: 'Hammer Curls', nameEn: 'Hammer Curls', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 3,
        focus: 'Legs A - Ayaqlar',
        focusRu: 'Legs A - Ноги',
        focusTr: 'Legs A - Bacaklar',
        focusEn: 'Legs A - Legs',
        exercises: [
          { name: 'Squat', nameRu: 'Приседания', nameTr: 'Squat', nameEn: 'Squat', sets: 4, reps: '6-8', rest: '3 dəq' },
          { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameTr: 'Romanian Deadlift', nameEn: 'Romanian Deadlift', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Leg Press', nameRu: 'Жим ногами', nameTr: 'Leg Press', nameEn: 'Leg Press', sets: 4, reps: '10-12', rest: '2 dəq' },
          { name: 'Walking Lunges', nameRu: 'Выпады вперёд', nameTr: 'Walking Lunges', nameEn: 'Walking Lunges', sets: 3, reps: '12 hər ayaq', rest: '90 san' },
          { name: 'Leg Extensions', nameRu: 'Разгибание ног', nameTr: 'Leg Extensions', nameEn: 'Leg Extensions', sets: 3, reps: '15-20', rest: '60 san' },
          { name: 'Leg Curl', nameRu: 'Сгибание ног', nameTr: 'Leg Curl', nameEn: 'Leg Curl', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Standing Calf Raises', nameRu: 'Подъёмы на носки стоя', nameTr: 'Standing Calf Raises', nameEn: 'Standing Calf Raises', sets: 5, reps: '15-20', rest: '60 san' },
        ]
      },
      {
        day: 4,
        focus: 'Push B - Sinə, Çiyin, Trisep',
        focusRu: 'Push B - Грудь, Плечи, Трицепс',
        focusTr: 'Push B - Göğüs, Omuz, Triseps',
        focusEn: 'Push B - Chest, Shoulders, Triceps',
        exercises: [
          { name: 'Incline Bench Press', nameRu: 'Жим на наклонной', nameTr: 'Incline Bench Press', nameEn: 'Incline Bench Press', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Dumbbell Bench Press', nameRu: 'Жим гантелей лёжа', nameTr: 'Dumbbell Bench Press', nameEn: 'Dumbbell Bench Press', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Dumbbell Shoulder Press', nameRu: 'Жим гантелей сидя', nameTr: 'Dumbbell Shoulder Press', nameEn: 'Dumbbell Shoulder Press', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Cable Lateral Raises', nameRu: 'Махи в кроссовере', nameTr: 'Cable Lateral Raises', nameEn: 'Cable Lateral Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Pec Deck Fly', nameRu: 'Сведение в бабочке', nameTr: 'Pec Deck Fly', nameEn: 'Pec Deck Fly', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Close-Grip Bench Press', nameRu: 'Жим узким хватом', nameTr: 'Close-Grip Bench Press', nameEn: 'Close-Grip Bench Press', sets: 3, reps: '8-10', rest: '90 san' },
          { name: 'Cable Pushdowns', nameRu: 'Разгибание в блоке', nameTr: 'Cable Pushdowns', nameEn: 'Cable Pushdowns', sets: 3, reps: '15-20', rest: '60 san' },
        ]
      },
      {
        day: 5,
        focus: 'Pull B - Arxa, Bisep',
        focusRu: 'Pull B - Спина, Бицепс',
        focusTr: 'Pull B - Sırt, Biseps',
        focusEn: 'Pull B - Back, Biceps',
        exercises: [
          { name: 'Sumo Deadlift', nameRu: 'Сумо становая тяга', nameTr: 'Sumo Deadlift', nameEn: 'Sumo Deadlift', sets: 4, reps: '6-8', rest: '2-3 dəq' },
          { name: 'Lat Pulldown', nameRu: 'Тяга верхнего блока', nameTr: 'Lat Pulldown', nameEn: 'Lat Pulldown', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'Chest-Supported Row', nameRu: 'Тяга с упором в грудь', nameTr: 'Chest-Supported Row', nameEn: 'Chest-Supported Row', sets: 4, reps: '10-12', rest: '90 san' },
          { name: 'One-Arm Dumbbell Row', nameRu: 'Тяга одной рукой', nameTr: 'One-Arm Dumbbell Row', nameEn: 'One-Arm Dumbbell Row', sets: 3, reps: '10-12', rest: '90 san' },
          { name: 'Reverse Flyes', nameRu: 'Обратная разводка', nameTr: 'Reverse Flyes', nameEn: 'Reverse Flyes', sets: 3, reps: '15-20', rest: '60 san' },
          { name: 'Incline Curls', nameRu: 'Сгибание на наклонной', nameTr: 'Incline Curls', nameEn: 'Incline Curls', sets: 4, reps: '12-15', rest: '60 san' },
          { name: 'Concentration Curls', nameRu: 'Концентрированные сгибания', nameTr: 'Concentration Curls', nameEn: 'Concentration Curls', sets: 3, reps: '12-15', rest: '60 san' },
        ]
      },
      {
        day: 6,
        focus: 'Legs B - Ayaqlar',
        focusRu: 'Legs B - Ноги',
        focusTr: 'Legs B - Bacaklar',
        focusEn: 'Legs B - Legs',
        exercises: [
          { name: 'Front Squat', nameRu: 'Фронтальные приседания', nameTr: 'Front Squat', nameEn: 'Front Squat', sets: 4, reps: '8-10', rest: '2 dəq' },
          { name: 'Hack Squat', nameRu: 'Гакк-приседания', nameTr: 'Hack Squat', nameEn: 'Hack Squat', sets: 4, reps: '10-12', rest: '2 dəq' },
          { name: 'Bulgarian Split Squats', nameRu: 'Болгарские приседания', nameTr: 'Bulgarian Split Squats', nameEn: 'Bulgarian Split Squats', sets: 3, reps: '10 hər ayaq', rest: '90 san' },
          { name: 'Lying Leg Curl', nameRu: 'Сгибание ног лёжа', nameTr: 'Lying Leg Curl', nameEn: 'Lying Leg Curl', sets: 4, reps: '12-15', rest: '60 san' },
          { name: 'Seated Leg Curl', nameRu: 'Сгибание ног сидя', nameTr: 'Seated Leg Curl', nameEn: 'Seated Leg Curl', sets: 3, reps: '12-15', rest: '60 san' },
          { name: 'Seated Calf Raises', nameRu: 'Подъёмы на носки сидя', nameTr: 'Seated Calf Raises', nameEn: 'Seated Calf Raises', sets: 4, reps: '15-20', rest: '60 san' },
          { name: 'Cable Crunches', nameRu: 'Скручивания в блоке', nameTr: 'Cable Crunches', nameEn: 'Cable Crunches', sets: 4, reps: '15-20', rest: '60 san' },
        ]
      }
    ]
  }
];

export function getProgramByDays(days: number): WorkoutProgram | undefined {
  return workoutPrograms.find(p => p.daysPerWeek === days);
}
