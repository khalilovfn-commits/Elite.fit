import React, { useState, useEffect } from 'react';
import { 
  User, Dumbbell, TrendingUp, Home, Camera, 
  ChevronRight, Plus, Save, Trash2,
  Upload, Calendar, Activity, Globe,
  Zap, BarChart3
} from 'lucide-react';
import { LanguageProvider, useLanguage } from '@/context/LanguageContext';
import { workoutPrograms, type WorkoutDay } from '@/data/workouts';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

// Types
interface UserProfile {
  name: string;
  age: string;
  height: string;
  weight: string;
  goal: string;
  experience: string;
}

interface Measurement {
  id: string;
  date: string;
  chest: string;
  waist: string;
  hips: string;
  arms: string;
  thighs: string;
  weight: string;
}

interface ProgressPhoto {
  id: string;
  date: string;
  type: 'front' | 'back' | 'side';
  url: string;
}

type Page = 'home' | 'profile' | 'workouts' | 'progress';

// Main App Component
function App() {
  return (
    <LanguageProvider>
      <EliteFitApp />
    </LanguageProvider>
  );
}

function EliteFitApp() {
  const { t, currentLanguage, setLanguage, availableLanguages } = useLanguage();
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [profile, setProfile] = useState<UserProfile>({
    name: '',
    age: '',
    height: '',
    weight: '',
    goal: 'buildMuscle',
    experience: 'beginner'
  });
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [photos, setPhotos] = useState<ProgressPhoto[]>([]);
  const [selectedWorkoutDays, setSelectedWorkoutDays] = useState<number>(3);

  // Load data from localStorage
  useEffect(() => {
    const savedProfile = localStorage.getItem('elitefit-profile');
    const savedMeasurements = localStorage.getItem('elitefit-measurements');
    const savedPhotos = localStorage.getItem('elitefit-photos');
    const savedWorkoutDays = localStorage.getItem('elitefit-workout-days');
    
    if (savedProfile) setProfile(JSON.parse(savedProfile));
    if (savedMeasurements) setMeasurements(JSON.parse(savedMeasurements));
    if (savedPhotos) setPhotos(JSON.parse(savedPhotos));
    if (savedWorkoutDays) setSelectedWorkoutDays(parseInt(savedWorkoutDays));
  }, []);

  const saveProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
    localStorage.setItem('elitefit-profile', JSON.stringify(newProfile));
    toast.success(t.profile.saved);
  };

  const addMeasurement = (measurement: Omit<Measurement, 'id'>) => {
    const newMeasurement = { ...measurement, id: Date.now().toString() };
    const updated = [...measurements, newMeasurement];
    setMeasurements(updated);
    localStorage.setItem('elitefit-measurements', JSON.stringify(updated));
  };

  const deleteMeasurement = (id: string) => {
    const updated = measurements.filter(m => m.id !== id);
    setMeasurements(updated);
    localStorage.setItem('elitefit-measurements', JSON.stringify(updated));
  };

  const addPhoto = (photo: Omit<ProgressPhoto, 'id'>) => {
    const newPhoto = { ...photo, id: Date.now().toString() };
    const updated = [...photos, newPhoto];
    setPhotos(updated);
    localStorage.setItem('elitefit-photos', JSON.stringify(updated));
  };

  const deletePhoto = (id: string) => {
    const updated = photos.filter(p => p.id !== id);
    setPhotos(updated);
    localStorage.setItem('elitefit-photos', JSON.stringify(updated));
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage t={t} onStart={() => setCurrentPage('profile')} />;
      case 'profile':
        return <ProfilePage t={t} profile={profile} onSave={saveProfile} />;
      case 'workouts':
        return <WorkoutsPage 
          t={t} 
          selectedDays={selectedWorkoutDays}
          onSelectDays={(days) => {
            setSelectedWorkoutDays(days);
            localStorage.setItem('elitefit-workout-days', days.toString());
          }}
        />;
      case 'progress':
        return <ProgressPage 
          t={t} 
          measurements={measurements}
          photos={photos}
          onAddMeasurement={addMeasurement}
          onDeleteMeasurement={deleteMeasurement}
          onAddPhoto={addPhoto}
          onDeletePhoto={deletePhoto}
        />;
      default:
        return <HomePage t={t} onStart={() => setCurrentPage('profile')} />;
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-background/80 border-b border-border/50">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl gold-button flex items-center justify-center">
                <Dumbbell className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold gold-text">EliteFit Pro</h1>
                <p className="text-xs text-muted-foreground">{t.home.subtitle}</p>
              </div>
            </div>
            
            {/* Language Selector */}
            <div className="flex items-center gap-1">
              {availableLanguages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code)}
                  className={`lang-option ${currentLanguage === lang.code ? 'active' : ''}`}
                  title={lang.name}
                >
                  <span className="text-lg">{lang.flag}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6 animate-fade-in">
        {renderPage()}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 backdrop-blur-xl bg-background/90 border-t border-border/50">
        <div className="max-w-md mx-auto px-4 py-2">
          <div className="flex items-center justify-around">
            <button 
              onClick={() => setCurrentPage('home')}
              className={`nav-item flex flex-col items-center gap-1 ${currentPage === 'home' ? 'active' : ''}`}
            >
              <Home className="w-5 h-5" />
              <span className="text-xs">{t.nav.home}</span>
            </button>
            <button 
              onClick={() => setCurrentPage('profile')}
              className={`nav-item flex flex-col items-center gap-1 ${currentPage === 'profile' ? 'active' : ''}`}
            >
              <User className="w-5 h-5" />
              <span className="text-xs">{t.nav.profile}</span>
            </button>
            <button 
              onClick={() => setCurrentPage('workouts')}
              className={`nav-item flex flex-col items-center gap-1 ${currentPage === 'workouts' ? 'active' : ''}`}
            >
              <Dumbbell className="w-5 h-5" />
              <span className="text-xs">{t.nav.workouts}</span>
            </button>
            <button 
              onClick={() => setCurrentPage('progress')}
              className={`nav-item flex flex-col items-center gap-1 ${currentPage === 'progress' ? 'active' : ''}`}
            >
              <TrendingUp className="w-5 h-5" />
              <span className="text-xs">{t.nav.progress}</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
}

// Home Page Component
function HomePage({ t, onStart }: { t: any; onStart: () => void }) {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="text-center py-12">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
          <Zap className="w-4 h-4" />
          <span>Elite Fitness Experience</span>
        </div>
        <h2 className="text-4xl md:text-5xl font-bold mb-4">
          <span className="gold-text">{t.home.welcome}</span>
        </h2>
        <p className="text-lg text-muted-foreground max-w-md mx-auto mb-8">
          {t.home.description}
        </p>
        <button 
          onClick={onStart}
          className="gold-button px-8 py-4 rounded-xl text-base font-semibold inline-flex items-center gap-2"
        >
          {t.home.startJourney}
          <ChevronRight className="w-5 h-5" />
        </button>
      </section>

      {/* Features Grid */}
      <section>
        <h3 className="section-title text-center mb-6">{t.home.features.title}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="elite-card p-5 text-center">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Dumbbell className="w-6 h-6 text-primary" />
            </div>
            <p className="text-sm font-medium">{t.home.features.workouts}</p>
          </div>
          <div className="elite-card p-5 text-center">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Activity className="w-6 h-6 text-primary" />
            </div>
            <p className="text-sm font-medium">{t.home.features.tracking}</p>
          </div>
          <div className="elite-card p-5 text-center">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Camera className="w-6 h-6 text-primary" />
            </div>
            <p className="text-sm font-medium">{t.home.features.photos}</p>
          </div>
          <div className="elite-card p-5 text-center">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Globe className="w-6 h-6 text-primary" />
            </div>
            <p className="text-sm font-medium">{t.home.features.multilingual}</p>
          </div>
        </div>
      </section>

      {/* Stats Preview */}
      <section className="elite-card p-6">
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">Nəticələrinizi izləyin</h3>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold gold-text">4</p>
            <p className="text-xs text-muted-foreground">Dil</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold gold-text">4</p>
            <p className="text-xs text-muted-foreground">Proqram</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold gold-text">100+</p>
            <p className="text-xs text-muted-foreground">Məşq</p>
          </div>
        </div>
      </section>
    </div>
  );
}

// Profile Page Component
function ProfilePage({ t, profile, onSave }: { t: any; profile: UserProfile; onSave: (p: UserProfile) => void }) {
  const [formData, setFormData] = useState(profile);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <User className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h2 className="section-title mb-0">{t.profile.title}</h2>
          <p className="text-sm text-muted-foreground">{t.profile.personalInfo}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="elite-card p-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">{t.profile.name}</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="elite-input"
              placeholder="Adınız"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">{t.profile.age}</Label>
            <Input
              type="number"
              value={formData.age}
              onChange={(e) => setFormData({ ...formData, age: e.target.value })}
              className="elite-input"
              placeholder="25"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">{t.profile.height}</Label>
            <Input
              type="number"
              value={formData.height}
              onChange={(e) => setFormData({ ...formData, height: e.target.value })}
              className="elite-input"
              placeholder="175"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">{t.profile.weight}</Label>
            <Input
              type="number"
              value={formData.weight}
              onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
              className="elite-input"
              placeholder="70"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-muted-foreground">{t.profile.goal}</Label>
          <Select 
            value={formData.goal} 
            onValueChange={(value) => setFormData({ ...formData, goal: value })}
          >
            <SelectTrigger className="elite-input">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-card border-border">
              <SelectItem value="loseWeight">{t.profile.goals.loseWeight}</SelectItem>
              <SelectItem value="buildMuscle">{t.profile.goals.buildMuscle}</SelectItem>
              <SelectItem value="maintain">{t.profile.goals.maintain}</SelectItem>
              <SelectItem value="strength">{t.profile.goals.strength}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-muted-foreground">{t.profile.experience}</Label>
          <Select 
            value={formData.experience} 
            onValueChange={(value) => setFormData({ ...formData, experience: value })}
          >
            <SelectTrigger className="elite-input">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-card border-border">
              <SelectItem value="beginner">{t.profile.experiences.beginner}</SelectItem>
              <SelectItem value="intermediate">{t.profile.experiences.intermediate}</SelectItem>
              <SelectItem value="advanced">{t.profile.experiences.advanced}</SelectItem>
              <SelectItem value="expert">{t.profile.experiences.expert}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <button type="submit" className="gold-button w-full py-3 rounded-xl flex items-center justify-center gap-2">
          <Save className="w-4 h-4" />
          {t.profile.save}
        </button>
      </form>
    </div>
  );
}

// Workouts Page Component
function WorkoutsPage({ 
  t, 
  selectedDays, 
  onSelectDays 
}: { 
  t: any; 
  selectedDays: number; 
  onSelectDays: (days: number) => void;
}) {
  const program = workoutPrograms.find(p => p.daysPerWeek === selectedDays);

  const getDayLabel = (day: number) => {
    const labels = ['day1', 'day2', 'day3', 'day4', 'day5', 'day6'];
    return t.workouts.dayLabels[labels[day - 1]] || `Day ${day}`;
  };

  const getFocusName = (day: WorkoutDay) => {
    switch (t) {
      case 'ru': return day.focusRu;
      case 'tr': return day.focusTr;
      case 'en': return day.focusEn;
      default: return day.focus;
    }
  };

  return (
    <div className="animate-slide-up">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <Dumbbell className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h2 className="section-title mb-0">{t.workouts.title}</h2>
          <p className="text-sm text-muted-foreground">{t.workouts.subtitle}</p>
        </div>
      </div>

      {/* Day Selector */}
      <div className="mb-6">
        <p className="text-sm text-muted-foreground mb-3">{t.workouts.selectDays}</p>
        <div className="flex gap-2 flex-wrap">
          {[3, 4, 5, 6].map((days) => (
            <button
              key={days}
              onClick={() => onSelectDays(days)}
              className={`tab-button ${selectedDays === days ? 'active' : ''}`}
            >
              {days} {t.workouts.days[['three', 'four', 'five', 'six'][days - 3]]}
            </button>
          ))}
        </div>
      </div>

      {/* Program Description */}
      {program && (
        <div className="elite-card p-4 mb-6">
          <p className="text-sm text-muted-foreground">
            {program.description}
          </p>
        </div>
      )}

      {/* Workout Days */}
      <div className="space-y-4">
        {program?.days.map((day) => (
          <div key={day.day} className="workout-day-card">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="text-primary font-bold">{day.day}</span>
              </div>
              <div>
                <h4 className="font-semibold">{getDayLabel(day.day)}</h4>
                <p className="text-sm text-primary">{getFocusName(day)}</p>
              </div>
            </div>

            <div className="space-y-2">
              {day.exercises.map((exercise, idx) => (
                <div key={idx} className="exercise-row">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded bg-muted flex items-center justify-center text-xs text-muted-foreground">
                      {idx + 1}
                    </span>
                    <span className="font-medium text-sm">{exercise.name}</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>{exercise.sets} {t.workouts.exercises.sets}</span>
                    <span>{exercise.reps} {t.workouts.exercises.reps}</span>
                    <span className="text-primary">{exercise.rest}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Progress Page Component
function ProgressPage({
  t,
  measurements,
  photos,
  onAddMeasurement,
  onDeleteMeasurement,
  onAddPhoto,
  onDeletePhoto
}: {
  t: any;
  measurements: Measurement[];
  photos: ProgressPhoto[];
  onAddMeasurement: (m: Omit<Measurement, 'id'>) => void;
  onDeleteMeasurement: (id: string) => void;
  onAddPhoto: (p: Omit<ProgressPhoto, 'id'>) => void;
  onDeletePhoto: (id: string) => void;
}) {
  const [activeTab, setActiveTab] = useState<'photos' | 'measurements'>('photos');
  const [showMeasurementForm, setShowMeasurementForm] = useState(false);
  const [showPhotoForm, setShowPhotoForm] = useState(false);
  const [newMeasurement, setNewMeasurement] = useState({
    date: new Date().toISOString().split('T')[0],
    chest: '',
    waist: '',
    hips: '',
    arms: '',
    thighs: '',
    weight: ''
  });
  const [newPhoto, setNewPhoto] = useState({
    date: new Date().toISOString().split('T')[0],
    type: 'front' as 'front' | 'back' | 'side',
    url: ''
  });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewPhoto({ ...newPhoto, url: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddMeasurement = () => {
    onAddMeasurement(newMeasurement);
    setShowMeasurementForm(false);
    setNewMeasurement({
      date: new Date().toISOString().split('T')[0],
      chest: '',
      waist: '',
      hips: '',
      arms: '',
      thighs: '',
      weight: ''
    });
  };

  const handleAddPhoto = () => {
    if (newPhoto.url) {
      onAddPhoto(newPhoto);
      setShowPhotoForm(false);
      setNewPhoto({
        date: new Date().toISOString().split('T')[0],
        type: 'front',
        url: ''
      });
    }
  };

  const sortedMeasurements = [...measurements].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const latestMeasurement = sortedMeasurements[0];
  const firstMeasurement = sortedMeasurements[sortedMeasurements.length - 1];

  return (
    <div className="animate-slide-up">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <TrendingUp className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h2 className="section-title mb-0">{t.progress.title}</h2>
          <p className="text-sm text-muted-foreground">{t.progress.subtitle}</p>
        </div>
      </div>

      {/* Stats Overview */}
      {latestMeasurement && (
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="stats-card">
            <p className="stats-value">{latestMeasurement.weight}</p>
            <p className="stats-label">{t.progress.stats.currentWeight}</p>
          </div>
          <div className="stats-card">
            <p className="stats-value">{sortedMeasurements.length}</p>
            <p className="stats-label">{t.progress.stats.daysActive}</p>
          </div>
          <div className="stats-card">
            <p className="stats-value">
              {firstMeasurement && latestMeasurement 
                ? (parseFloat(latestMeasurement.weight) - parseFloat(firstMeasurement.weight)).toFixed(1)
                : '0'}
            </p>
            <p className="stats-label">{t.progress.stats.totalLost}</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setActiveTab('photos')}
          className={`tab-button ${activeTab === 'photos' ? 'active' : ''}`}
        >
          <Camera className="w-4 h-4 inline mr-2" />
          {t.progress.photos.title}
        </button>
        <button
          onClick={() => setActiveTab('measurements')}
          className={`tab-button ${activeTab === 'measurements' ? 'active' : ''}`}
        >
          <Activity className="w-4 h-4 inline mr-2" />
          {t.progress.measurements.title}
        </button>
      </div>

      {/* Photos Tab */}
      {activeTab === 'photos' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-semibold">{t.progress.photos.title}</h3>
            <button
              onClick={() => setShowPhotoForm(true)}
              className="gold-button px-4 py-2 rounded-lg text-sm flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              {t.progress.photos.upload}
            </button>
          </div>

          {showPhotoForm && (
            <div className="elite-card p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-muted-foreground">{t.progress.photos.date}</Label>
                  <Input
                    type="date"
                    value={newPhoto.date}
                    onChange={(e) => setNewPhoto({ ...newPhoto, date: e.target.value })}
                    className="elite-input mt-1"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">{t.common.select}</Label>
                  <Select 
                    value={newPhoto.type} 
                    onValueChange={(value: any) => setNewPhoto({ ...newPhoto, type: value })}
                  >
                    <SelectTrigger className="elite-input mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      <SelectItem value="front">{t.progress.photos.front}</SelectItem>
                      <SelectItem value="back">{t.progress.photos.back}</SelectItem>
                      <SelectItem value="side">{t.progress.photos.side}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="photo-upload h-40" onClick={() => document.getElementById('photo-input')?.click()}>
                {newPhoto.url ? (
                  <img src={newPhoto.url} alt="Preview" className="h-full w-full object-cover rounded-lg" />
                ) : (
                  <>
                    <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">{t.progress.photos.upload}</p>
                  </>
                )}
                <input
                  id="photo-input"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handlePhotoUpload}
                />
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setShowPhotoForm(false)}
                  className="elite-button flex-1 py-2 rounded-lg"
                >
                  {t.common.cancel}
                </button>
                <button
                  onClick={handleAddPhoto}
                  className="gold-button flex-1 py-2 rounded-lg"
                  disabled={!newPhoto.url}
                >
                  {t.common.save}
                </button>
              </div>
            </div>
          )}

          {photos.length === 0 ? (
            <div className="elite-card p-8 text-center text-muted-foreground">
              <Camera className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>{t.progress.photos.noPhotos}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {photos.map((photo) => (
                <div key={photo.id} className="elite-card overflow-hidden">
                  <div className="aspect-square">
                    <img src={photo.url} alt={photo.type} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-3 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium capitalize">{t.progress.photos[photo.type]}</p>
                      <p className="text-xs text-muted-foreground">{photo.date}</p>
                    </div>
                    <button
                      onClick={() => onDeletePhoto(photo.id)}
                      className="p-2 rounded-lg hover:bg-destructive/10 text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Measurements Tab */}
      {activeTab === 'measurements' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-semibold">{t.progress.measurements.title}</h3>
            <button
              onClick={() => setShowMeasurementForm(true)}
              className="gold-button px-4 py-2 rounded-lg text-sm flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              {t.progress.measurements.add}
            </button>
          </div>

          {showMeasurementForm && (
            <div className="elite-card p-4 space-y-4">
              <div>
                <Label className="text-sm text-muted-foreground">{t.progress.measurements.date}</Label>
                <Input
                  type="date"
                  value={newMeasurement.date}
                  onChange={(e) => setNewMeasurement({ ...newMeasurement, date: e.target.value })}
                  className="elite-input mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-sm text-muted-foreground">{t.progress.measurements.chest}</Label>
                  <Input
                    type="number"
                    value={newMeasurement.chest}
                    onChange={(e) => setNewMeasurement({ ...newMeasurement, chest: e.target.value })}
                    className="elite-input mt-1"
                    placeholder="100"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">{t.progress.measurements.waist}</Label>
                  <Input
                    type="number"
                    value={newMeasurement.waist}
                    onChange={(e) => setNewMeasurement({ ...newMeasurement, waist: e.target.value })}
                    className="elite-input mt-1"
                    placeholder="80"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">{t.progress.measurements.hips}</Label>
                  <Input
                    type="number"
                    value={newMeasurement.hips}
                    onChange={(e) => setNewMeasurement({ ...newMeasurement, hips: e.target.value })}
                    className="elite-input mt-1"
                    placeholder="95"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">{t.progress.measurements.arms}</Label>
                  <Input
                    type="number"
                    value={newMeasurement.arms}
                    onChange={(e) => setNewMeasurement({ ...newMeasurement, arms: e.target.value })}
                    className="elite-input mt-1"
                    placeholder="35"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">{t.progress.measurements.thighs}</Label>
                  <Input
                    type="number"
                    value={newMeasurement.thighs}
                    onChange={(e) => setNewMeasurement({ ...newMeasurement, thighs: e.target.value })}
                    className="elite-input mt-1"
                    placeholder="55"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">{t.progress.measurements.weight}</Label>
                  <Input
                    type="number"
                    value={newMeasurement.weight}
                    onChange={(e) => setNewMeasurement({ ...newMeasurement, weight: e.target.value })}
                    className="elite-input mt-1"
                    placeholder="70"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setShowMeasurementForm(false)}
                  className="elite-button flex-1 py-2 rounded-lg"
                >
                  {t.common.cancel}
                </button>
                <button
                  onClick={handleAddMeasurement}
                  className="gold-button flex-1 py-2 rounded-lg"
                >
                  {t.common.save}
                </button>
              </div>
            </div>
          )}

          {sortedMeasurements.length === 0 ? (
            <div className="elite-card p-8 text-center text-muted-foreground">
              <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>{t.progress.measurements.noData}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {sortedMeasurements.map((m) => (
                <div key={m.id} className="elite-card p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-primary" />
                      <span className="font-medium">{m.date}</span>
                    </div>
                    <button
                      onClick={() => onDeleteMeasurement(m.id)}
                      className="p-2 rounded-lg hover:bg-destructive/10 text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div className="text-center p-2 rounded-lg bg-muted">
                      <p className="text-muted-foreground text-xs">{t.progress.measurements.weight}</p>
                      <p className="font-semibold gold-text">{m.weight} kg</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-muted">
                      <p className="text-muted-foreground text-xs">{t.progress.measurements.chest}</p>
                      <p className="font-semibold">{m.chest} cm</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-muted">
                      <p className="text-muted-foreground text-xs">{t.progress.measurements.waist}</p>
                      <p className="font-semibold">{m.waist} cm</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;
